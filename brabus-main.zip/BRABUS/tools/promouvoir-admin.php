<?php
// Utilitaire local uniquement : aucun endpoint web de promotion.
if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit('Cet outil fonctionne uniquement dans le terminal.');
}
require __DIR__ . '/../config/connexion.php';
if ((int)$bdd->query("SELECT COUNT(*) FROM utilisateur WHERE role='admin'")->fetchColumn() > 0) {
    fwrite(STDERR, "Un administrateur existe déjà. Aucun changement effectué.\n");
    exit(1);
}
echo "Adresse e-mail du compte créé sur le site : ";
$email = trim((string)fgets(STDIN));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    fwrite(STDERR, "Adresse e-mail invalide.\n");
    exit(1);
}
$query = $bdd->prepare('SELECT id_utilisateur FROM utilisateur WHERE email = :email');
$query->execute([':email' => $email]);
$id = $query->fetchColumn();
if (!$id) {
    fwrite(STDERR, "Compte introuvable. Créez-le depuis frontend/inscription.html.\n");
    exit(1);
}
$query = $bdd->prepare("UPDATE utilisateur SET role='admin' WHERE id_utilisateur=:id");
$query->execute([':id' => $id]);
echo "Compte promu administrateur. Déconnectez-vous puis reconnectez-vous au site.\n";
