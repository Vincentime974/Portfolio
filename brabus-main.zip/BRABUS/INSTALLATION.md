# Remettre BRABUS en fonctionnement sur Windows

Cette base est une reconstruction compatible avec les requêtes du code fourni. Elle ne récupère pas les données de l’ancien ordinateur.

## 1. Préparer le serveur

Utilisez une installation locale de XAMPP disposant de PHP et MySQL/MariaDB. Décompressez le dossier BRABUS de l’archive dans `C:\xampp\htdocs\brabus`. Les dossiers `api`, `config`, `database`, `frontend` et `tools` doivent se trouver directement dans ce dossier.

Dans le panneau XAMPP, démarrez **Apache** et **MySQL**.

## 2. Créer la base

Ouvrez `http://localhost/phpmyadmin` dans votre navigateur. Cliquez sur **Importer**, choisissez `database/01-schema.sql`, puis lancez l’importation. Le fichier crée la base `brabus` et les cinq tables.

Importez ensuite `database/02-catalogue-demo.sql`. Il ajoute huit véhicules fictifs utilisant vos images, avec des performances et prix laissés non renseignés. Les boutiques, avis, messages et utilisateurs restent vides.

Ces fichiers ne contiennent pas de suppression de table. Une deuxième importation du catalogue n’ajoute pas de doublons lorsque les mêmes noms et images existent déjà. Ils ne migrent pas une autre base dont la structure serait différente.

## 3. Relier le site

Dans le dossier `config`, copiez `connexion.example.php` et nommez la copie `connexion.local.php`. Laissez les valeurs proposées si vous utilisez une installation locale XAMPP standard. Si votre compte MySQL possède un mot de passe ou utilise un autre port, adaptez ces champs dans cette copie.

Ouvrez `http://localhost/brabus/frontend/index.html`. Le catalogue doit afficher huit véhicules. Ne double-cliquez pas sur le fichier HTML pour utiliser les fonctions PHP : ouvrez toujours l’adresse `http://localhost/...`.

## 4. Créer votre administrateur

Depuis le site, cliquez sur **Créer un compte** et choisissez votre propre adresse e-mail et un mot de passe d’au moins douze caractères.

Ouvrez PowerShell et lancez :

```powershell
& 'C:\xampp\php\php.exe' 'C:\xampp\htdocs\brabus\tools\promouvoir-admin.php'
```

Quand l’outil vous le demande, saisissez l’adresse du compte que vous venez de créer. Il devient le premier administrateur. Aucun compte ou mot de passe administrateur prédéfini n’est fourni.

Connectez-vous ensuite au site. Si vous étiez déjà connecté, déconnectez-vous puis reconnectez-vous. Le lien **Administration** doit apparaître. Vous pourrez ajouter des boutiques, compléter les caractéristiques et gérer le catalogue.

## 5. Vérifier

- Consultez une fiche de véhicule.
- Créez un avis et une demande de contact depuis votre compte connecté.
- Dans l’administration, vérifiez leur présence et ajoutez une boutique de test.
- Redémarrez MySQL et vérifiez que les données sont toujours présentes.

Les messages sont stockés dans votre base et affichés dans l’administration ; ils ne sont pas envoyés à la marque BRABUS.

## 6. Sauvegarder

Dans phpMyAdmin, sélectionnez `brabus`, puis **Exporter** au format SQL. Conservez cet export et une copie du projet sur un autre support. Après chaque modification importante, refaites un export.

## En cas de problème

**Catalogue indisponible :** vérifiez MySQL, les imports et `connexion.local.php`. Ouvrez `http://localhost/brabus/api/get_vehicules.php` : vous devez voir une réponse JSON avec `success: true`.

**Impossible de se connecter :** utilisez le compte nouvellement créé. Les anciens comptes et mots de passe n’existent pas dans cette nouvelle base.

**Port déjà utilisé :** vérifiez les ports dans XAMPP et adaptez l’URL ou le port de connexion MySQL.

**Pas de lien Administration :** exécutez la promotion, puis reconnectez-vous.

## Vérification effectuée ici

La correspondance des tables et colonnes avec les requêtes PHP et les images du catalogue a été vérifiée. L’import MySQL et l’exécution PHP restent à vérifier sur votre installation : ces services ne sont pas présents dans l’environnement de travail.
