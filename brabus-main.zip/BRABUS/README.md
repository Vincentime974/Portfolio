# BRABUS — refonte graphique

Projet pédagogique indépendant de Vincent Anavillela, non affilié à la marque. Refonte du catalogue, accueil, fiches techniques, connexion, inscription, avis, contact et harmonisation de l’administration.

## Démonstration statique
La démonstration embarquée dans le portfolio utilise uniquement le dossier frontend avec BRABUS_DEMO=true dans js/config.js. Les huit modèles sont fictifs, d’après les images fournies. Aucune performance, prix, boutique ou avis n’est inventé. Aucun compte ni message n’est enregistré en démonstration.

## Projet PHP complet
Les dossiers api et config sont conservés. Placer le projet dans un serveur PHP avec PDO MySQL. Configurer config/connexion.php pour votre environnement et votre base existante, puis ouvrir frontend/index.html. BRABUS_DEMO=false utilise les endpoints PHP d’origine. Ne pas exposer les identifiants de base de données.

La base a été reconstruite : les fichiers database/01-schema.sql et database/02-catalogue-demo.sql créent les cinq tables et le catalogue fictif. Consultez INSTALLATION.md pour démarrer le site, créer votre compte administrateur et sauvegarder la nouvelle base. Aucune ancienne donnée n’a été récupérée. Les intégrations PHP/MySQL restent à vérifier sur votre ordinateur.

## Modifications
Navigation mobile et clavier ; filtre et recherche de modèles ; catalogue stable ; carrousel manuel unique ; correction du champ sujet de contact ; gestion des erreurs ; rendu des contenus publics par textContent ; mode démo explicite ; responsive et réduction des animations.

Les endpoints serveur ont été conservés et ne constituent pas un audit complet de sécurité du backend.
