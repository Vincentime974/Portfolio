<?php
$settings = [
    'host' => getenv('BRABUS_DB_HOST') ?: '127.0.0.1',
    'port' => getenv('BRABUS_DB_PORT') ?: '3306',
    'database' => getenv('BRABUS_DB_NAME') ?: 'brabus',
    'username' => getenv('BRABUS_DB_USER') ?: 'root',
    'password' => getenv('BRABUS_DB_PASSWORD') ?: '',
];
$localFile = __DIR__ . '/connexion.local.php';
if (is_file($localFile)) {
    $local = require $localFile;
    if (is_array($local)) $settings = array_merge($settings, $local);
}
try {
    $bdd = new PDO(
        'mysql:host=' . $settings['host'] . ';port=' . $settings['port'] . ';dbname=' . $settings['database'] . ';charset=utf8mb4',
        $settings['username'], $settings['password'],
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::ATTR_EMULATE_PREPARES => false]
    );
} catch (PDOException $e) {
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, "Connexion MySQL impossible. Vérifiez les imports et config/connexion.local.php.\n");
    } else {
        http_response_code(503);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => false, 'message' => 'Base indisponible. Vérifiez MySQL et la configuration locale.']);
    }
    exit(1);
}
