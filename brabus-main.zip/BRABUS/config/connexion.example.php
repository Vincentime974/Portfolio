<?php
// Configuration locale. Copier ce fichier sous le nom connexion.local.php.
// Avec XAMPP, les valeurs ci-dessous correspondent à une installation locale standard.
return [
    'host' => '127.0.0.1',
    'port' => '3306',
    'database' => 'brabus',
    'username' => 'root',
    'password' => '',
];
