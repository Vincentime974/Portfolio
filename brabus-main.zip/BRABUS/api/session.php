<?php
session_start();

header('Content-Type: application/json');

if (isset($_SESSION['connecte']) && $_SESSION['connecte'] === true) {
    echo json_encode([
        "connecte" => true,
        "id_utilisateur" => $_SESSION['id_utilisateur'],
        "nom" => $_SESSION['nom'],
        "prenom" => $_SESSION['prenom'],
        "role" => $_SESSION['role']
    ]);
} else {
    echo json_encode([
        "connecte" => false
    ]);
}
?>
