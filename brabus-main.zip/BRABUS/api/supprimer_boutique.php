<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

try {
    $id = $_POST["id_boutique"] ?? $_GET["id_boutique"] ?? null;

    if (!$id) {
        echo json_encode([
            "success" => false,
            "message" => "ID boutique manquant"
        ]);
        exit();
    }

    $requete = $bdd->prepare("DELETE FROM boutique WHERE id_boutique = :id_boutique");
    $requete->execute([":id_boutique" => $id]);

    echo json_encode([
        "success" => true,
        "message" => "Boutique supprimée"
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
