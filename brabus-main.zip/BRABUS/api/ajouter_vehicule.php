<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

try {
    $requete = $bdd->prepare("INSERT INTO vehicule 
        (marque, modele, image, type, moteur, puissance, couple, transmission, acceleration, vitesseMax, prix, description)
        VALUES 
        (:marque, :modele, :image, :type, :moteur, :puissance, :couple, :transmission, :acceleration, :vitesseMax, :prix, :description)");

    $requete->execute([
        ":marque" => $_POST["marque"] ?? "",
        ":modele" => $_POST["modele"] ?? "",
        ":image" => $_POST["image"] ?? "",
        ":type" => $_POST["type"] ?? "",
        ":moteur" => $_POST["moteur"] ?? "",
        ":puissance" => $_POST["puissance"] ?? "",
        ":couple" => $_POST["couple"] ?? "",
        ":transmission" => $_POST["transmission"] ?? "",
        ":acceleration" => $_POST["acceleration"] ?? "",
        ":vitesseMax" => $_POST["vitesseMax"] ?? "",
        ":prix" => (isset($_POST["prix"]) && trim($_POST["prix"]) !== "" ? $_POST["prix"] : null),
        ":description" => $_POST["description"] ?? ""
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Véhicule ajouté"
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
