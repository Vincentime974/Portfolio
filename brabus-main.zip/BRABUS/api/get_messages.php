<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

try {
    $requete = $bdd->query("SELECT message_contact.*, utilisateur.nom, utilisateur.prenom, utilisateur.email
        FROM message_contact
        INNER JOIN utilisateur ON message_contact.id_utilisateur = utilisateur.id_utilisateur
        ORDER BY message_contact.id_message DESC");

    $messages = $requete->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "messages" => $messages
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
