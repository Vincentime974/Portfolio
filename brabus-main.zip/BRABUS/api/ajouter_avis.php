<?php
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Connectez-vous ou créez un compte pour envoyer un avis."
    ]);
    exit();
}

require __DIR__ . '/../config/connexion.php';

$note = $_POST['note'] ?? '';
$commentaire = $_POST['commentaire'] ?? '';
$id_vehicule = $_POST['id_vehicule'] ?? '';
$id_utilisateur = $_SESSION['id_utilisateur'];

if ($id_vehicule === '') {
    echo json_encode([
        "success" => false,
        "message" => "Veuillez choisir un modèle de véhicule."
    ]);
    exit();
}

if ($commentaire === '') {
    echo json_encode([
        "success" => false,
        "message" => "Veuillez écrire un commentaire."
    ]);
    exit();
}

if (filter_var($note, FILTER_VALIDATE_INT) === false || (int)$note < 1 || (int)$note > 5 || !ctype_digit((string)$id_vehicule) || trim($commentaire) === '' || strlen($commentaire) > 12000) {
    echo json_encode(['success' => false, 'message' => 'Vérifiez le modèle, la note entre 1 et 5 et le commentaire.']);
    exit();
}
try {
    $requete = $bdd->prepare("INSERT INTO avis 
        (note, commentaire, date_avis, id_utilisateur, id_vehicule)
        VALUES 
        (:note, :commentaire, CURDATE(), :id_utilisateur, :id_vehicule)");

    $requete->execute([
        ":note" => $note,
        ":commentaire" => $commentaire,
        ":id_utilisateur" => $id_utilisateur,
        ":id_vehicule" => $id_vehicule
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Avis envoyé avec succès."
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
