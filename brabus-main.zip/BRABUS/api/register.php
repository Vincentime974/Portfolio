<?php

session_start();

header('Content-Type: application/json');

require __DIR__ . '/../config/connexion.php';

$nom = $_POST['nom'] ?? '';
$prenom = $_POST['prenom'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if ($nom === '' || $prenom === '' || $email === '' || $password === '') {
    echo json_encode([
        "success" => false,
        "message" => "Veuillez remplir tous les champs."
    ]);
    exit();
}

$email = trim($email);
$nom = trim($nom);
$prenom = trim($prenom);
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 254 || strlen($password) < 12 || strlen($password) > 72 || $nom === '' || $prenom === '' || strlen($nom) > 100 || strlen($prenom) > 100) {
    echo json_encode(['success' => false, 'message' => 'Vérifiez votre nom et votre e-mail. Le mot de passe doit comporter de 12 à 72 octets.']);
    exit();
}

try {
    $mot_de_passe = password_hash($password, PASSWORD_DEFAULT);

    $requete = $bdd->prepare("INSERT INTO utilisateur (nom, prenom, email, mot_de_passe, role)
    VALUES (:nom, :prenom, :email, :mot_de_passe, :role)");

    $requete->execute([
        ":nom" => $nom,
        ":prenom" => $prenom,
        ":email" => $email,
        ":mot_de_passe" => $mot_de_passe,
        ":role" => "utilisateur"
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Compte créé"
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur lors de l'inscription : " . "Erreur de traitement. Vérifiez les données et la base."
    ]);
}

?>
