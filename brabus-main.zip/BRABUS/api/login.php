<?php

session_start();

header('Content-Type: application/json');

require __DIR__ . '/../config/connexion.php';

$email = $_POST['email'] ?? '';
$mot_de_passe = $_POST['password'] ?? '';

$requete = $bdd->prepare("SELECT * FROM utilisateur WHERE email = :email");
$requete->bindParam(':email', $email);
$requete->execute();

$utilisateur = $requete->fetch(PDO::FETCH_ASSOC);

if ($utilisateur && password_verify($mot_de_passe, $utilisateur['mot_de_passe'])) {

    session_regenerate_id(true);
    $_SESSION['connecte'] = true;
    $_SESSION['id_utilisateur'] = $utilisateur['id_utilisateur'];
    $_SESSION['nom'] = $utilisateur['nom'];
    $_SESSION['prenom'] = $utilisateur['prenom'];
    $_SESSION['role'] = $utilisateur['role'];

    echo json_encode([
        "success" => true,
        "message" => "Connexion réussie",
        "role" => $utilisateur['role']
    ]);

} else {

    echo json_encode([
        "success" => false,
        "message" => "Email ou mot de passe incorrect"
    ]);

}
?>
