<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

try {
    $requete = $bdd->prepare("INSERT INTO boutique 
        (nom, adresse, ville, code_postal, horaires)
        VALUES 
        (:nom, :adresse, :ville, :code_postal, :horaires)");

    $requete->execute([
        ":nom" => $_POST["nom"] ?? "",
        ":adresse" => $_POST["adresse"] ?? "",
        ":ville" => $_POST["ville"] ?? "",
        ":code_postal" => $_POST["code_postal"] ?? "",
        ":horaires" => $_POST["horaires"] ?? ""
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Boutique ajoutée"
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
