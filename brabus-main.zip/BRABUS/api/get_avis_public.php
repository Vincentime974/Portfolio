<?php
header('Content-Type: application/json');

require __DIR__ . '/../config/connexion.php';

try {
    $requete = $bdd->query("SELECT avis.note, avis.commentaire, avis.date_avis,
        utilisateur.nom, utilisateur.prenom,
        vehicule.marque, vehicule.modele
        FROM avis
        INNER JOIN utilisateur ON avis.id_utilisateur = utilisateur.id_utilisateur
        INNER JOIN vehicule ON avis.id_vehicule = vehicule.id_vehicule
        ORDER BY avis.id_avis DESC");

    $avis = $requete->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "avis" => $avis
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>