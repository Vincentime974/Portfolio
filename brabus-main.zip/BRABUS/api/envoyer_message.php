<?php
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true) {
    echo json_encode([
        "success" => false,
        "message" => "Connectez-vous ou créez un compte pour contacter l'entreprise."
    ]);
    exit();
}

require __DIR__ . '/../config/connexion.php';

$sujet = $_POST['sujet'] ?? '';
$message = $_POST['message'] ?? '';
$telephone = $_POST['telephone'] ?? '';
$id_utilisateur = $_SESSION['id_utilisateur'];

try {
    $requete = $bdd->prepare("INSERT INTO message_contact
        (sujet, message, telephone, date_envoi, id_utilisateur)
        VALUES
        (:sujet, :message, :telephone, CURDATE(), :id_utilisateur)");

    $requete->execute([
        ":sujet" => $sujet,
        ":message" => $message,
        ":telephone" => $telephone,
        ":id_utilisateur" => $id_utilisateur
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Message envoyé avec succès."
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
