<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

try {
    $id = $_POST["id_vehicule"] ?? null;

    if (!$id) {
        echo json_encode([
            "success" => false,
            "message" => "ID véhicule manquant"
        ]);
        exit();
    }

    $requete = $bdd->prepare("UPDATE vehicule SET
        marque = :marque,
        modele = :modele,
        image = :image,
        type = :type,
        moteur = :moteur,
        puissance = :puissance,
        couple = :couple,
        transmission = :transmission,
        acceleration = :acceleration,
        vitesseMax = :vitesseMax,
        prix = :prix,
        description = :description
        WHERE id_vehicule = :id_vehicule
    ");

    $requete->execute([
        ":marque" => $_POST["marque"] ?? "",
        ":modele" => $_POST["modele"] ?? "",
        ":image" => $_POST["image"] ?? "",
        ":type" => $_POST["type"] ?? "",
        ":moteur" => $_POST["moteur"] ?? "",
        ":puissance" => $_POST["puissance"] ?? "",
        ":couple" => $_POST["couple"] ?? "",
        ":transmission" => $_POST["transmission"] ?? "",
        ":acceleration" => $_POST["acceleration"] ?? "",
        ":vitesseMax" => $_POST["vitesseMax"] ?? "",
        ":prix" => (isset($_POST["prix"]) && trim($_POST["prix"]) !== "" ? $_POST["prix"] : null),
        ":description" => $_POST["description"] ?? "",
        ":id_vehicule" => $id
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Véhicule modifié",
        "id_vehicule" => $id,
        "lignes_modifiees" => $requete->rowCount()
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
