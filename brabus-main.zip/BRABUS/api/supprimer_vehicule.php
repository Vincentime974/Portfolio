<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

try {
    $id = $_POST["id_vehicule"] ?? $_GET["id_vehicule"] ?? null;

    if (!$id) {
        echo json_encode([
            "success" => false,
            "message" => "ID véhicule manquant"
        ]);
        exit();
    }

    $requete = $bdd->prepare("DELETE FROM vehicule WHERE id_vehicule = :id_vehicule");
    $requete->execute([":id_vehicule" => $id]);

    echo json_encode([
        "success" => true,
        "message" => "Véhicule supprimé"
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
