<?php
require_once __DIR__ . '/_admin_guard.php';

echo json_encode([
    "success" => true,
    "role" => "admin"
]);
?>
