<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['connecte']) || $_SESSION['connecte'] !== true || !isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode([
        "success" => false,
        "message" => "Accès refusé"
    ]);
    exit();
}
?>
