<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

try {
    $id = $_POST["id_boutique"] ?? null;

    if (!$id) {
        echo json_encode([
            "success" => false,
            "message" => "ID boutique manquant"
        ]);
        exit();
    }

    $requete = $bdd->prepare("UPDATE boutique SET
        nom = :nom,
        adresse = :adresse,
        ville = :ville,
        code_postal = :code_postal,
        horaires = :horaires
        WHERE id_boutique = :id_boutique");

    $requete->execute([
        ":nom" => $_POST["nom"] ?? "",
        ":adresse" => $_POST["adresse"] ?? "",
        ":ville" => $_POST["ville"] ?? "",
        ":code_postal" => $_POST["code_postal"] ?? "",
        ":horaires" => $_POST["horaires"] ?? "",
        ":id_boutique" => $id
    ]);

    echo json_encode([
        "success" => true,
        "message" => "Boutique modifiée"
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
