<?php
require_once __DIR__ . '/_admin_guard.php';
require __DIR__ . '/../config/connexion.php';

$id = $_POST['id_avis'] ?? $_GET['id_avis'] ?? null;

if (!$id) {
    echo json_encode([
        "success" => false,
        "message" => "ID avis manquant."
    ]);
    exit();
}

try {
    $requete = $bdd->prepare("DELETE FROM avis WHERE id_avis = :id_avis");
    $requete->execute([":id_avis" => $id]);

    echo json_encode([
        "success" => true,
        "message" => "Avis supprimé."
    ]);

} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
