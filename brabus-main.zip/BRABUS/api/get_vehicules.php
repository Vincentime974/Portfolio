<?php
header('Content-Type: application/json');
require __DIR__ . '/../config/connexion.php';

try {
    $requete = $bdd->query("SELECT * FROM vehicule ORDER BY id_vehicule DESC");
    $vehicules = $requete->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "success" => true,
        "vehicules" => $vehicules
    ]);
} catch (Exception $e) {
    echo json_encode([
        "success" => false,
        "message" => "Erreur de traitement. Vérifiez les données et la base."
    ]);
}
?>
