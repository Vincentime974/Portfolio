-- Catalogue fictif, non récupéré de l’ancienne base. Importer après 01-schema.sql.
USE brabus;

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'Inferno', 'images/cars/inferno.png', 'SUV', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='Inferno' AND image='images/cars/inferno.png');

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'Falcon', 'images/cars/falcon.png', 'Sportive', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='Falcon' AND image='images/cars/falcon.png');

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'Cullinan', 'images/cars/cullinan.png', 'SUV', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='Cullinan' AND image='images/cars/cullinan.png');

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'Rocket', 'images/cars/rocket.png', 'Berline', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='Rocket' AND image='images/cars/rocket.png');

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'Phantom', 'images/cars/phantom.png', 'Berline', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='Phantom' AND image='images/cars/phantom.png');

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'E-Titan', 'images/cars/etitan.png', 'SUV', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='E-Titan' AND image='images/cars/etitan.png');

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'Cyber X', 'images/cars/cyberx.png', 'SUV', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='Cyber X' AND image='images/cars/cyberx.png');

INSERT INTO vehicule (marque, modele, image, type, description)
SELECT 'BRABUS', 'Deep Black', 'images/cars/deepblack.png', 'Sportive', 'Modèle fictif de démonstration du projet pédagogique. Caractéristiques à renseigner.'
WHERE NOT EXISTS (SELECT 1 FROM vehicule WHERE marque='BRABUS' AND modele='Deep Black' AND image='images/cars/deepblack.png');

