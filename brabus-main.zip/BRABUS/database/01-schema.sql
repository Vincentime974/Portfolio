-- Reconstruction à partir des requêtes PHP du projet. Aucun effacement.
CREATE DATABASE IF NOT EXISTS brabus CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE brabus;

CREATE TABLE IF NOT EXISTS utilisateur (
  id_utilisateur INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nom VARCHAR(100) NOT NULL,
  prenom VARCHAR(100) NOT NULL,
  email VARCHAR(254) NOT NULL,
  mot_de_passe VARCHAR(255) NOT NULL,
  role ENUM('utilisateur','admin') NOT NULL DEFAULT 'utilisateur',
  PRIMARY KEY (id_utilisateur),
  UNIQUE KEY uq_utilisateur_email (email)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS vehicule (
  id_vehicule INT UNSIGNED NOT NULL AUTO_INCREMENT,
  marque VARCHAR(100) NOT NULL DEFAULT '',
  modele VARCHAR(150) NOT NULL DEFAULT '',
  image VARCHAR(500) NOT NULL DEFAULT '',
  type VARCHAR(100) NOT NULL DEFAULT '',
  moteur VARCHAR(150) NOT NULL DEFAULT '',
  puissance VARCHAR(100) NOT NULL DEFAULT '',
  couple VARCHAR(100) NOT NULL DEFAULT '',
  transmission VARCHAR(150) NOT NULL DEFAULT '',
  acceleration VARCHAR(100) NOT NULL DEFAULT '',
  vitesseMax VARCHAR(100) NOT NULL DEFAULT '',
  prix DECIMAL(12,2) NULL DEFAULT NULL,
  description TEXT NOT NULL,
  PRIMARY KEY (id_vehicule)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS boutique (
  id_boutique INT UNSIGNED NOT NULL AUTO_INCREMENT,
  nom VARCHAR(150) NOT NULL,
  adresse VARCHAR(255) NOT NULL DEFAULT '',
  ville VARCHAR(150) NOT NULL DEFAULT '',
  code_postal VARCHAR(20) NOT NULL DEFAULT '',
  horaires VARCHAR(255) NOT NULL DEFAULT '',
  PRIMARY KEY (id_boutique)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS avis (
  id_avis INT UNSIGNED NOT NULL AUTO_INCREMENT,
  note TINYINT UNSIGNED NOT NULL,
  commentaire TEXT NOT NULL,
  date_avis DATE NOT NULL,
  id_utilisateur INT UNSIGNED NOT NULL,
  id_vehicule INT UNSIGNED NOT NULL,
  PRIMARY KEY (id_avis),
  CONSTRAINT fk_avis_utilisateur FOREIGN KEY (id_utilisateur) REFERENCES utilisateur(id_utilisateur) ON DELETE CASCADE,
  CONSTRAINT fk_avis_vehicule FOREIGN KEY (id_vehicule) REFERENCES vehicule(id_vehicule) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS message_contact (
  id_message INT UNSIGNED NOT NULL AUTO_INCREMENT,
  sujet VARCHAR(200) NOT NULL DEFAULT '',
  message TEXT NOT NULL,
  telephone VARCHAR(50) NOT NULL DEFAULT '',
  date_envoi DATE NOT NULL,
  id_utilisateur INT UNSIGNED NOT NULL,
  PRIMARY KEY (id_message),
  CONSTRAINT fk_message_utilisateur FOREIGN KEY (id_utilisateur) REFERENCES utilisateur(id_utilisateur) ON DELETE CASCADE
) ENGINE=InnoDB;
