from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from datetime import date


app = FastAPI()

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

taches = []
users=[]

@app.get("/")
def accueil():
    return {"message": "API tâches à faire"}


@app.get("/taches")
def liste_taches():
    return taches


@app.post("/taches")
def ajouter_tache(tache: dict):
    taches.append(tache)
    return {"message": "Tâche ajoutée", "tache": tache}


@app.delete("/taches/{id}")
def supprimer_tache(id: int):
    for tache in taches:
        if tache["id"] == id:
            taches.remove(tache)
            return {"message": "Tâche supprimée"}

    return {"erreur": "Tâche introuvable"}


@app.post("/users")
def ajouter_user(user: dict):
    users.append(user)
    return {"message": "Utilisateur ajouté", "user": user}