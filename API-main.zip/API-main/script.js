async function chargerTaches() {
    const reponse = await fetch("http://127.0.0.1:8000/taches");
    const taches = await reponse.json();

    const liste = document.getElementById("liste");
    const notification = document.getElementById("notification");

    liste.innerHTML = "";
    notification.innerHTML = "";

    for (const tache of taches) {
        const dateTache = new Date(tache.date);
        const maintenant = new Date();

        const difference = dateTache - maintenant;

        if (difference > 0 && difference <= 24 * 60 * 60 * 1000) {
            notification.innerHTML += `
                <p style="color: white;">
                    ⚠️ La tâche "${tache.titre}" arrive dans moins de 24h !
                </p>
            `;
        }

        liste.innerHTML += `
            <li>
                <strong>${tache.titre}</strong>
                - Date limite : ${tache.date}
                <button onclick="supprimerTache(${tache.id})">Fait</button>
            </li>
        `;
    }
}


async function ajouterTache() {
    const titre = document.getElementById("titre").value;
    const date = document.getElementById("date").value;

    const nouvelleTache = {
        id: Date.now(),
        titre: titre,
        date: date,
        terminee: false
    };

    await fetch("http://127.0.0.1:8000/taches", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(nouvelleTache)
    });

    chargerTaches();
}


async function supprimerTache(id) {
    await fetch(`http://127.0.0.1:8000/taches/${id}`, {
        method: "DELETE"
    });

    chargerTaches();
}


chargerTaches();

function ouvrirConnexion() {
  document.getElementById("login").style.display = "block";
}
function ouvrirRegister() {
  document.getElementById("register").style.display = "block";
}