# Mes tâches — refonte

Interface responsive avec ajout, suppression, validation et réouverture des tâches, recherche, filtres, tri, échéances et progression.

## Démonstration
Ouvrir index.html. Les trois tâches initiales sont des exemples. Les données sont conservées dans ce navigateur, sans compte et sans serveur.

## API Python
Avec Python 3.10 ou supérieur :

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --host 127.0.0.1 --port 8000
```

Ouvrir http://127.0.0.1:8000/app/, cliquer sur la roue dentée et sélectionner API Python, adresse http://127.0.0.1:8000. Documentation : http://127.0.0.1:8000/docs.

L’API conserve les données dans tasks.sqlite3. Le mode démonstration et le mode API ont des listes distinctes. L’API valide les titres et dates, refuse les doublons et retourne une erreur 404 pour les tâches absentes. Une tâche terminée reste conservée et peut être réouverte.

Le projet est un espace local personnel : aucune authentification n’est implémentée. Les anciens formulaires sans traitement et l’endpoint utilisateurs non sécurisé ont été retirés. Garder le serveur sur 127.0.0.1. Avant toute mise en ligne multiutilisateur, ajouter authentification et isolation des tâches.

Polices Google Fonts avec repli Arial ; aucune dépendance JavaScript pour l’interface. Le portfolio embarque uniquement la démonstration statique.
