from pathlib import Path
from datetime import date
import sqlite3
from fastapi import FastAPI, HTTPException, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, field_validator

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'tasks.sqlite3'
app = FastAPI(title='Mes tâches', version='2.0')
app.add_middleware(CORSMiddleware, allow_origins=['http://127.0.0.1:8000', 'http://localhost:8000', 'http://127.0.0.1:4174'], allow_methods=['GET', 'POST', 'PATCH', 'DELETE'], allow_headers=['Content-Type'])

def connection():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute('CREATE TABLE IF NOT EXISTS tasks (id INTEGER PRIMARY KEY, titre TEXT NOT NULL, date TEXT NOT NULL, terminee INTEGER NOT NULL DEFAULT 0)')
    return conn

class Task(BaseModel):
    id: int = Field(gt=0)
    titre: str = Field(min_length=1, max_length=200)
    date: date
    terminee: bool = False

    @field_validator('titre')
    @classmethod
    def clean_title(cls, value):
        value = value.strip()
        if not value:
            raise ValueError('Le titre ne peut pas être vide.')
        return value

class Update(BaseModel):
    terminee: bool

def to_task(row):
    return {**dict(row), 'terminee': bool(row['terminee'])}

@app.get('/taches')
def list_tasks():
    with connection() as conn:
        return [to_task(row) for row in conn.execute('SELECT * FROM tasks ORDER BY date, id')]

@app.post('/taches', status_code=201)
def create_task(task: Task):
    try:
        with connection() as conn:
            conn.execute('INSERT INTO tasks VALUES (?, ?, ?, ?)', (task.id, task.titre, task.date.isoformat(), int(task.terminee)))
    except sqlite3.IntegrityError:
        raise HTTPException(409, 'Identifiant déjà utilisé.')
    return task

@app.patch('/taches/{task_id}')
def update_task(task_id: int, update: Update):
    with connection() as conn:
        result = conn.execute('UPDATE tasks SET terminee=? WHERE id=?', (int(update.terminee), task_id))
        if result.rowcount == 0:
            raise HTTPException(404, 'Tâche introuvable.')
        return to_task(conn.execute('SELECT * FROM tasks WHERE id=?', (task_id,)).fetchone())

@app.delete('/taches/{task_id}', status_code=204)
def delete_task(task_id: int):
    with connection() as conn:
        if conn.execute('DELETE FROM tasks WHERE id=?', (task_id,)).rowcount == 0:
            raise HTTPException(404, 'Tâche introuvable.')
    return Response(status_code=204)

@app.get('/')
def root():
    from fastapi.responses import RedirectResponse
    return RedirectResponse('/app/')

@app.get('/app/')
def frontend():
    return FileResponse(ROOT / 'index.html')

@app.get('/app/{filename}')
def asset(filename: str):
    if filename not in ('style.css', 'script.js'):
        raise HTTPException(404, 'Fichier introuvable.')
    return FileResponse(ROOT / filename)
